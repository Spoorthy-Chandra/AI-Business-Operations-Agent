# AI Agent Suite - Quick Start Guide

## 🚀 Getting Started in 5 Minutes

### Step 1: First Login
1. Open the application in your browser
2. You'll see the login page with two tabs: **Login** and **Sign Up**
3. Click on **Sign Up** tab
4. Enter a username (letters, numbers, and underscores only)
5. Create a password (minimum 6 characters)
6. Confirm your password
7. Click **Create Account**

**Important**: The first user to register automatically becomes an administrator!

### Step 2: Explore the Dashboard
After logging in, you'll see the main dashboard with four colorful agent cards:

1. **Reception Agent** (Blue) - Process voice calls
2. **Meeting Scheduler** (Purple) - Manage meetings
3. **Task Manager** (Green) - Track tasks
4. **Knowledge Base** (Yellow) - AI-powered documents

### Step 3: Try Each Agent

#### 📞 Reception Agent
1. Click on the **Reception Agent** card
2. Click **Add Call Log** button
3. Enter a caller ID (e.g., "John Doe")
4. Enter the call transcript
5. Optionally add call duration (in minutes)
6. Optionally add notes
7. Click **Create Call Log**
8. View the call log in your list!

#### 📅 Meeting Scheduler
1. Click on the **Meeting Scheduler** card
2. Click **Schedule Meeting** button
3. Fill in the meeting details:
   - Title (required)
   - Description
   - Start and end times
   - Location (physical or video link)
   - Participants (comma-separated)
4. Click **Create Meeting**
5. Your meeting appears in the list!

#### ✅ Task Manager
1. Click on the **Task Manager** card
2. Click **Add Task** button
3. Enter task details:
   - Title (required)
   - Description
   - Status (To Do, In Progress, Done)
   - Priority (Low, Medium, High)
   - Category
   - Due date
   - Progress percentage
4. Click **Create Task**
5. View your tasks in Kanban board or list view!

#### 📚 Knowledge Base
1. Click on the **Knowledge Base** card
2. Click **Upload Document** button
3. Enter a title for your document
4. Upload a file (PDF, DOCX, or TXT)
5. Optionally add tags (comma-separated)
6. Click **Upload Document**
7. Switch to the **AI Chat** tab
8. Ask questions about your documents!
9. The AI will use your uploaded documents to answer

### Step 4: Admin Features (First User Only)
If you're the first user (admin), you'll see an **Admin** link in the header:

1. Click **Admin** in the navigation
2. View all registered users
3. Change user roles (User or Admin)
4. View system statistics

## 🎯 Key Features to Try

### Search & Filter
- **Reception**: Search call logs by caller ID, transcript, or notes
- **Knowledge Base**: Search documents by title or content

### Edit & Delete
- All items can be edited or deleted using the action buttons
- Click the edit icon to modify
- Click the trash icon to delete

### Progress Tracking
- **Tasks**: Use the progress slider to track completion (0-100%)
- **Dashboard**: View task completion rates in real-time

### AI Chat
- Upload documents to the Knowledge Base
- Ask questions in natural language
- Get AI-powered answers based on your documents
- Responses stream in real-time

## 💡 Pro Tips

1. **Organize Tasks**: Use categories to group related tasks
2. **Tag Documents**: Add tags to documents for easy filtering
3. **Add Notes**: Use the notes field in call logs for important details
4. **Set Priorities**: Mark urgent tasks as high priority
5. **Track Progress**: Update task progress regularly for accurate statistics

## 🔐 Security Notes

- Each user can only see their own data
- Admins can see all data and manage users
- Audio files and documents are securely stored
- All data is encrypted in transit and at rest

## 📱 Mobile Access

The application is responsive and works on mobile devices:
- Use the hamburger menu (☰) to access navigation
- All features are available on mobile
- Optimized for touch interactions

## 🆘 Troubleshooting

### Can't Login?
- Check your username and password
- Username can only contain letters, numbers, and underscores
- Password must be at least 6 characters

### Upload Failed?
- **Documents**: Must be under 10MB (PDF, DOCX, TXT)
- Check your internet connection

### AI Not Responding?
- Make sure you've uploaded documents first
- Wait a few seconds for the AI to process
- Check your internet connection

## 🎉 You're All Set!

Start streamlining your business operations with AI Agent Suite. Explore each agent and discover how they can help you work more efficiently!

## 📞 Need Help?

- Check the PROJECT_SUMMARY.md for detailed feature documentation
- Review the README.md for technical setup information
- Contact support if you encounter any issues

---

**Happy Organizing! 🚀**
