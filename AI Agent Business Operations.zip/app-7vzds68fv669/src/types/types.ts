export type UserRole = 'user' | 'admin';

export interface Profile {
  id: string;
  username: string | null;
  email: string | null;
  role: UserRole;
  created_at: string;
}

export interface CallLog {
  id: string;
  user_id: string;
  caller_id: string | null;
  audio_url: string | null;
  transcript: string | null;
  duration: number | null;
  notes: string | null;
  created_at: string;
}

export interface Meeting {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  start_time: string;
  end_time: string;
  location: string | null;
  participants: string[] | null;
  is_recurring: boolean;
  recurrence_rule: string | null;
  status: 'scheduled' | 'completed' | 'cancelled';
  created_at: string;
  updated_at: string;
}

export interface Task {
  id: string;
  user_id: string;
  title: string;
  description: string | null;
  status: 'todo' | 'in_progress' | 'done';
  priority: 'low' | 'medium' | 'high';
  category: string | null;
  due_date: string | null;
  progress: number;
  created_at: string;
  updated_at: string;
}

export interface Document {
  id: string;
  user_id: string;
  title: string;
  file_url: string;
  file_type: string;
  file_size: number | null;
  content: string | null;
  tags: string[] | null;
  created_at: string;
  updated_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: 'meeting' | 'task' | 'system';
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface DashboardStats {
  totalCalls: number;
  totalMeetings: number;
  totalTasks: number;
  completedTasks: number;
  totalDocuments: number;
  unreadNotifications: number;
}
