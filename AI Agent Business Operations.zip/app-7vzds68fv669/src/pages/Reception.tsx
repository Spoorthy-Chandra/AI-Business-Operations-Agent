import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { callLogsApi } from '@/db/api';
import { supabase } from '@/db/supabase';
import type { CallLog } from '@/types/types';
import { Phone, Plus, Search, Loader2, FileAudio, Trash2, Edit } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';

export default function Reception() {
  const [callLogs, setCallLogs] = useState<CallLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [callerId, setCallerId] = useState('');
  const [transcript, setTranscript] = useState('');
  const [notes, setNotes] = useState('');
  const [duration, setDuration] = useState('');
  const [editingLog, setEditingLog] = useState<CallLog | null>(null);
  const [dialogOpen, setDialogOpen] = useState(false);

  useEffect(() => {
    loadCallLogs();
  }, []);

  const loadCallLogs = async () => {
    try {
      const data = await callLogsApi.getCallLogs();
      setCallLogs(data);
    } catch (error) {
      console.error('Failed to load call logs:', error);
      toast.error('Failed to load call logs');
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setCallerId('');
    setTranscript('');
    setNotes('');
    setDuration('');
    setEditingLog(null);
  };

  const handleSubmit = async () => {
    if (!callerId || !transcript) {
      toast.error('Please enter caller ID and transcript');
      return;
    }

    setSaving(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const durationInSeconds = duration ? parseInt(duration) * 60 : null;

      if (editingLog) {
        const updated = await callLogsApi.updateCallLog(editingLog.id, {
          caller_id: callerId,
          transcript,
          notes: notes || null,
          duration: durationInSeconds
        });
        setCallLogs(callLogs.map(log => log.id === updated.id ? updated : log));
        toast.success('Call log updated successfully!');
      } else {
        const newCallLog = await callLogsApi.createCallLog({
          user_id: user.id,
          caller_id: callerId,
          audio_url: null,
          transcript,
          duration: durationInSeconds,
          notes: notes || null
        });
        setCallLogs([newCallLog, ...callLogs]);
        toast.success('Call log created successfully!');
      }

      resetForm();
      setDialogOpen(false);
    } catch (error: unknown) {
      const err = error as Error;
      console.error('Save error:', err);
      toast.error(err.message || 'Failed to save call log');
    } finally {
      setSaving(false);
    }
  };

  const handleSearch = async () => {
    if (!searchQuery.trim()) {
      loadCallLogs();
      return;
    }

    try {
      const results = await callLogsApi.searchCallLogs(searchQuery);
      setCallLogs(results);
    } catch (error) {
      console.error('Search failed:', error);
      toast.error('Search failed');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await callLogsApi.deleteCallLog(id);
      setCallLogs(callLogs.filter(log => log.id !== id));
      toast.success('Call log deleted');
    } catch (error) {
      console.error('Delete failed:', error);
      toast.error('Failed to delete call log');
    }
  };

  const handleEdit = (log: CallLog) => {
    setEditingLog(log);
    setCallerId(log.caller_id || '');
    setTranscript(log.transcript || '');
    setNotes(log.notes || '');
    setDuration(log.duration ? Math.floor(log.duration / 60).toString() : '');
    setDialogOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-3xl font-bold flex items-center gap-3">
              <div className="w-10 h-10 bg-reception rounded-xl flex items-center justify-center">
                <Phone className="w-6 h-6 text-white" />
              </div>
              Reception Agent
            </h1>
            <p className="text-muted-foreground">Manage call logs and transcripts</p>
          </div>

          <Dialog open={dialogOpen} onOpenChange={(open) => {
            setDialogOpen(open);
            if (!open) resetForm();
          }}>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="mr-2 h-4 w-4" />
                Add Call Log
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-md">
              <DialogHeader>
                <DialogTitle>{editingLog ? 'Edit Call Log' : 'Add Call Log'}</DialogTitle>
                <DialogDescription>
                  {editingLog ? 'Update call log details' : 'Create a new call log entry'}
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="caller-id">Caller ID *</Label>
                  <Input
                    id="caller-id"
                    placeholder="Enter caller ID or name"
                    value={callerId}
                    onChange={(e) => setCallerId(e.target.value)}
                    disabled={saving}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="transcript">Transcript *</Label>
                  <Textarea
                    id="transcript"
                    placeholder="Enter call transcript"
                    value={transcript}
                    onChange={(e) => setTranscript(e.target.value)}
                    disabled={saving}
                    rows={5}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="duration">Duration (minutes)</Label>
                  <Input
                    id="duration"
                    type="number"
                    placeholder="Enter call duration in minutes"
                    value={duration}
                    onChange={(e) => setDuration(e.target.value)}
                    disabled={saving}
                    min="0"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="notes">Notes (Optional)</Label>
                  <Textarea
                    id="notes"
                    placeholder="Add any notes about this call"
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    disabled={saving}
                    rows={3}
                  />
                </div>
                <Button
                  onClick={handleSubmit}
                  disabled={!callerId || !transcript || saving}
                  className="w-full"
                >
                  {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  {saving ? 'Saving...' : editingLog ? 'Update Call Log' : 'Create Call Log'}
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Search Call Logs</CardTitle>
            <CardDescription>Search by caller ID, transcript, or notes</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                placeholder="Search call logs..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
              />
              <Button onClick={handleSearch}>
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="space-y-4">
          {loading ? (
            Array.from({ length: 3 }).map((_, i) => (
              <Card key={i}>
                <CardHeader>
                  <Skeleton className="h-6 w-48 bg-muted" />
                  <Skeleton className="h-4 w-32 bg-muted" />
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-20 w-full bg-muted" />
                </CardContent>
              </Card>
            ))
          ) : callLogs.length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-12">
                <FileAudio className="h-12 w-12 text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No call logs found</p>
                <p className="text-sm text-muted-foreground">Add a call log to get started</p>
              </CardContent>
            </Card>
          ) : (
            callLogs.map((log) => (
              <Card key={log.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="space-y-1">
                      <CardTitle className="flex items-center gap-2">
                        <Phone className="h-5 w-5 text-reception" />
                        {log.caller_id || 'Unknown Caller'}
                      </CardTitle>
                      <CardDescription>
                        {format(new Date(log.created_at), 'PPpp')}
                        {log.duration && ` • ${Math.floor(log.duration / 60)}m ${log.duration % 60}s`}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleEdit(log)}
                      >
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => handleDelete(log.id)}
                      >
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {log.transcript && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Transcript</Label>
                      <div className="p-4 bg-muted rounded-lg text-sm">
                        {log.transcript}
                      </div>
                    </div>
                  )}
                  {log.notes && (
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Notes</Label>
                      <div className="p-4 bg-muted rounded-lg text-sm">
                        {log.notes}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
