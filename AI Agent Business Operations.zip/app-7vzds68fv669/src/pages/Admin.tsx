import { useEffect, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { profilesApi } from '@/db/api';
import type { Profile } from '@/types/types';
import { Shield, Users } from 'lucide-react';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';

export default function Admin() {
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState<Profile | null>(null);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [profilesData, currentProfile] = await Promise.all([
        profilesApi.getAllProfiles(),
        profilesApi.getCurrentProfile()
      ]);
      setProfiles(profilesData);
      setCurrentUser(currentProfile);
    } catch (error) {
      console.error('Failed to load data:', error);
      toast.error('Failed to load user data');
    } finally {
      setLoading(false);
    }
  };

  const handleRoleChange = async (userId: string, newRole: 'user' | 'admin') => {
    try {
      const updated = await profilesApi.updateProfile(userId, { role: newRole });
      setProfiles(profiles.map(p => p.id === updated.id ? updated : p));
      toast.success('User role updated successfully');
    } catch (error: unknown) {
      const err = error as Error;
      console.error('Failed to update role:', err);
      toast.error(err.message || 'Failed to update user role');
    }
  };

  if (!currentUser || currentUser.role !== 'admin') {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Card className="max-w-md">
          <CardHeader>
            <CardTitle>Access Denied</CardTitle>
            <CardDescription>You do not have permission to access this page</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground">
              Only administrators can access the admin panel.
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-6">
        <div className="space-y-1">
          <h1 className="text-3xl font-bold flex items-center gap-3">
            <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center">
              <Shield className="w-6 h-6 text-white" />
            </div>
            Admin Panel
          </h1>
          <p className="text-muted-foreground">Manage users and system settings</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              User Management
            </CardTitle>
            <CardDescription>
              Manage user roles and permissions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {loading ? (
                Array.from({ length: 3 }).map((_, i) => (
                  <div key={i} className="flex items-center justify-between p-4 border border-border rounded-lg">
                    <div className="space-y-2">
                      <Skeleton className="h-5 w-32 bg-muted" />
                      <Skeleton className="h-4 w-48 bg-muted" />
                    </div>
                    <Skeleton className="h-10 w-32 bg-muted" />
                  </div>
                ))
              ) : profiles.length === 0 ? (
                <p className="text-center text-muted-foreground py-8">No users found</p>
              ) : (
                profiles.map((profile) => (
                  <div
                    key={profile.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="font-medium">{profile.username || 'Unknown User'}</p>
                        <Badge variant={profile.role === 'admin' ? 'default' : 'secondary'}>
                          {profile.role}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">
                        {profile.email || 'No email'}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Joined {format(new Date(profile.created_at), 'PP')}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Select
                        value={profile.role}
                        onValueChange={(value: 'user' | 'admin') => handleRoleChange(profile.id, value)}
                        disabled={profile.id === currentUser.id}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="user">User</SelectItem>
                          <SelectItem value="admin">Admin</SelectItem>
                        </SelectContent>
                      </Select>
                      {profile.id === currentUser.id && (
                        <Badge variant="outline" className="text-xs">
                          You
                        </Badge>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>System Statistics</CardTitle>
            <CardDescription>Overview of system usage</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 border border-border rounded-lg">
                <p className="text-sm text-muted-foreground">Total Users</p>
                <p className="text-2xl font-bold">{profiles.length}</p>
              </div>
              <div className="p-4 border border-border rounded-lg">
                <p className="text-sm text-muted-foreground">Administrators</p>
                <p className="text-2xl font-bold">
                  {profiles.filter(p => p.role === 'admin').length}
                </p>
              </div>
              <div className="p-4 border border-border rounded-lg">
                <p className="text-sm text-muted-foreground">Regular Users</p>
                <p className="text-2xl font-bold">
                  {profiles.filter(p => p.role === 'user').length}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
