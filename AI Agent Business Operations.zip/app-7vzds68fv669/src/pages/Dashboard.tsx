import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { dashboardApi } from '@/db/api';
import type { DashboardStats } from '@/types/types';
import { Phone, Calendar, CheckSquare, BookOpen, TrendingUp, Bell } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

export default function Dashboard() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, []);

  const loadStats = async () => {
    try {
      const data = await dashboardApi.getDashboardStats();
      setStats(data);
    } catch (error) {
      console.error('Failed to load dashboard stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const agents = [
    {
      name: 'Reception Agent',
      description: 'Process voice calls and transcripts',
      icon: Phone,
      color: 'bg-reception',
      link: '/reception',
      stat: stats?.totalCalls || 0,
      statLabel: 'Total Calls'
    },
    {
      name: 'Meeting Scheduler',
      description: 'Manage meetings and calendar',
      icon: Calendar,
      color: 'bg-meeting',
      link: '/meetings',
      stat: stats?.totalMeetings || 0,
      statLabel: 'Scheduled Meetings'
    },
    {
      name: 'Task Manager',
      description: 'Track tasks and progress',
      icon: CheckSquare,
      color: 'bg-task',
      link: '/tasks',
      stat: stats?.totalTasks || 0,
      statLabel: 'Total Tasks'
    },
    {
      name: 'Knowledge Base',
      description: 'AI-powered document Q&A',
      icon: BookOpen,
      color: 'bg-knowledge',
      link: '/knowledge',
      stat: stats?.totalDocuments || 0,
      statLabel: 'Documents'
    }
  ];

  const taskCompletionRate = stats && stats.totalTasks > 0
    ? Math.round((stats.completedTasks / stats.totalTasks) * 100)
    : 0;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6 space-y-8">
        <div className="space-y-2">
          <h1 className="text-4xl font-bold tracking-tight">AI Agent Suite</h1>
          <p className="text-muted-foreground text-lg">
            Streamline your business operations with intelligent agents
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
          {agents.map((agent) => (
            <Link key={agent.name} to={agent.link}>
              <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer h-full">
                <CardHeader>
                  <div className={`w-12 h-12 ${agent.color} rounded-xl flex items-center justify-center mb-3`}>
                    <agent.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-xl">{agent.name}</CardTitle>
                  <CardDescription>{agent.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <Skeleton className="h-8 w-20 bg-muted" />
                  ) : (
                    <div className="space-y-1">
                      <div className="text-3xl font-bold">{agent.stat}</div>
                      <div className="text-sm text-muted-foreground">{agent.statLabel}</div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Task Completion Rate</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-10 w-24 bg-muted" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{taskCompletionRate}%</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats?.completedTasks} of {stats?.totalTasks} tasks completed
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Unread Notifications</CardTitle>
              <Bell className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-10 w-16 bg-muted" />
              ) : (
                <>
                  <div className="text-3xl font-bold">{stats?.unreadNotifications || 0}</div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Pending notifications
                  </p>
                </>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Operations</CardTitle>
              <CheckSquare className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              {loading ? (
                <Skeleton className="h-10 w-16 bg-muted" />
              ) : (
                <>
                  <div className="text-3xl font-bold">
                    {(stats?.totalCalls || 0) + (stats?.totalMeetings || 0) + (stats?.totalTasks || 0)}
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">
                    Total operations tracked
                  </p>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Get started with your AI agents</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
            <Link to="/reception" className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
              <Phone className="w-5 h-5 text-reception mb-2" />
              <div className="font-medium">Process Call</div>
              <div className="text-sm text-muted-foreground">Upload and transcribe audio</div>
            </Link>
            <Link to="/meetings" className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
              <Calendar className="w-5 h-5 text-meeting mb-2" />
              <div className="font-medium">Schedule Meeting</div>
              <div className="text-sm text-muted-foreground">Create new meeting</div>
            </Link>
            <Link to="/tasks" className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
              <CheckSquare className="w-5 h-5 text-task mb-2" />
              <div className="font-medium">Add Task</div>
              <div className="text-sm text-muted-foreground">Create new task</div>
            </Link>
            <Link to="/knowledge" className="p-4 border border-border rounded-lg hover:bg-muted transition-colors">
              <BookOpen className="w-5 h-5 text-knowledge mb-2" />
              <div className="font-medium">Upload Document</div>
              <div className="text-sm text-muted-foreground">Add to knowledge base</div>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
