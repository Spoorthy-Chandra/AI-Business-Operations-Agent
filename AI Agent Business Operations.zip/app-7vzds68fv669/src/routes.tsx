import Dashboard from './pages/Dashboard';
import Reception from './pages/Reception';
import Meetings from './pages/Meetings';
import Tasks from './pages/Tasks';
import Knowledge from './pages/Knowledge';
import Admin from './pages/Admin';
import Login from './pages/Login';
import type { ReactNode } from 'react';

interface RouteConfig {
  name: string;
  path: string;
  element: ReactNode;
  visible?: boolean;
}

const routes: RouteConfig[] = [
  {
    name: 'Dashboard',
    path: '/',
    element: <Dashboard />,
    visible: true
  },
  {
    name: 'Reception',
    path: '/reception',
    element: <Reception />,
    visible: true
  },
  {
    name: 'Meetings',
    path: '/meetings',
    element: <Meetings />,
    visible: true
  },
  {
    name: 'Tasks',
    path: '/tasks',
    element: <Tasks />,
    visible: true
  },
  {
    name: 'Knowledge',
    path: '/knowledge',
    element: <Knowledge />,
    visible: true
  },
  {
    name: 'Admin',
    path: '/admin',
    element: <Admin />,
    visible: false
  },
  {
    name: 'Login',
    path: '/login',
    element: <Login />,
    visible: false
  }
];

export default routes;
