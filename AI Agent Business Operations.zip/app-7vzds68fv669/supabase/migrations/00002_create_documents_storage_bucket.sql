/*
# Create Storage Bucket for Documents

## 1. Storage Bucket
- Create `app-7vzds68fv669_documents` bucket for document uploads
- Max file size: 10MB
- Allowed MIME types: PDF, DOCX, TXT

## 2. Security
- Users can upload their own documents
- Users can read their own documents
- Admins have full access
*/

-- Create storage bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'app-7vzds68fv669_documents',
  'app-7vzds68fv669_documents',
  false,
  10485760,
  ARRAY['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain']
)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for documents bucket
CREATE POLICY "Users can upload own documents" ON storage.objects
  FOR INSERT TO authenticated
  WITH CHECK (
    bucket_id = 'app-7vzds68fv669_documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can read own documents" ON storage.objects
  FOR SELECT TO authenticated
  USING (
    bucket_id = 'app-7vzds68fv669_documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users can delete own documents" ON storage.objects
  FOR DELETE TO authenticated
  USING (
    bucket_id = 'app-7vzds68fv669_documents' AND
    auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Admins have full access to documents storage" ON storage.objects
  FOR ALL TO authenticated
  USING (
    bucket_id = 'app-7vzds68fv669_documents' AND
    is_admin(auth.uid())
  );
