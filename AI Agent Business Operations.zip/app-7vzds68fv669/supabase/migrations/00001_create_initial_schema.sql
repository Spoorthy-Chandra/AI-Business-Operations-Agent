/*
# Create Initial Schema for AI Agent Suite

## 1. New Tables

### profiles
- `id` (uuid, primary key, references auth.users)
- `username` (text, unique)
- `email` (text)
- `role` (user_role enum: 'user', 'admin')
- `created_at` (timestamptz)

### call_logs
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `caller_id` (text)
- `audio_url` (text)
- `transcript` (text)
- `duration` (integer, seconds)
- `notes` (text)
- `created_at` (timestamptz)

### meetings
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `title` (text)
- `description` (text)
- `start_time` (timestamptz)
- `end_time` (timestamptz)
- `location` (text)
- `participants` (text[])
- `is_recurring` (boolean)
- `recurrence_rule` (text)
- `status` (text: 'scheduled', 'completed', 'cancelled')
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### tasks
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `title` (text)
- `description` (text)
- `status` (text: 'todo', 'in_progress', 'done')
- `priority` (text: 'low', 'medium', 'high')
- `category` (text)
- `due_date` (timestamptz)
- `progress` (integer, 0-100)
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### documents
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `title` (text)
- `file_url` (text)
- `file_type` (text)
- `file_size` (integer)
- `content` (text, extracted text content)
- `tags` (text[])
- `created_at` (timestamptz)
- `updated_at` (timestamptz)

### notifications
- `id` (uuid, primary key)
- `user_id` (uuid, references profiles)
- `type` (text: 'meeting', 'task', 'system')
- `title` (text)
- `message` (text)
- `is_read` (boolean)
- `created_at` (timestamptz)

## 2. Security
- Enable RLS on all tables
- Users can only access their own data
- Admins have full access to all data
- Create helper function to check admin role

## 3. Notes
- First registered user becomes admin automatically
- All timestamps use timestamptz for timezone support
- Arrays used for participants and tags for flexibility
*/

-- Create user role enum
CREATE TYPE user_role AS ENUM ('user', 'admin');

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  username text UNIQUE,
  email text,
  role user_role DEFAULT 'user'::user_role NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create call_logs table
CREATE TABLE IF NOT EXISTS call_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  caller_id text,
  audio_url text,
  transcript text,
  duration integer,
  notes text,
  created_at timestamptz DEFAULT now()
);

-- Create meetings table
CREATE TABLE IF NOT EXISTS meetings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  start_time timestamptz NOT NULL,
  end_time timestamptz NOT NULL,
  location text,
  participants text[],
  is_recurring boolean DEFAULT false,
  recurrence_rule text,
  status text DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'completed', 'cancelled')),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create tasks table
CREATE TABLE IF NOT EXISTS tasks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text,
  status text DEFAULT 'todo' CHECK (status IN ('todo', 'in_progress', 'done')),
  priority text DEFAULT 'medium' CHECK (priority IN ('low', 'medium', 'high')),
  category text,
  due_date timestamptz,
  progress integer DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create documents table
CREATE TABLE IF NOT EXISTS documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  file_url text NOT NULL,
  file_type text NOT NULL,
  file_size integer,
  content text,
  tags text[],
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create notifications table
CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  type text CHECK (type IN ('meeting', 'task', 'system')),
  title text NOT NULL,
  message text NOT NULL,
  is_read boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS on all tables
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE call_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE meetings ENABLE ROW LEVEL SECURITY;
ALTER TABLE tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Create admin helper function
CREATE OR REPLACE FUNCTION is_admin(uid uuid)
RETURNS boolean LANGUAGE sql SECURITY DEFINER AS $$
  SELECT EXISTS (
    SELECT 1 FROM profiles p
    WHERE p.id = uid AND p.role = 'admin'::user_role
  );
$$;

-- Profiles policies
CREATE POLICY "Admins have full access to profiles" ON profiles
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can view own profile" ON profiles
  FOR SELECT TO authenticated USING (auth.uid() = id);

CREATE POLICY "Users can update own profile without changing role" ON profiles
  FOR UPDATE TO authenticated USING (auth.uid() = id) 
  WITH CHECK (auth.uid() = id AND role IS NOT DISTINCT FROM (SELECT role FROM profiles WHERE id = auth.uid()));

-- Call logs policies
CREATE POLICY "Admins have full access to call_logs" ON call_logs
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own call_logs" ON call_logs
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Meetings policies
CREATE POLICY "Admins have full access to meetings" ON meetings
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own meetings" ON meetings
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Tasks policies
CREATE POLICY "Admins have full access to tasks" ON tasks
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own tasks" ON tasks
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Documents policies
CREATE POLICY "Admins have full access to documents" ON documents
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own documents" ON documents
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Notifications policies
CREATE POLICY "Admins have full access to notifications" ON notifications
  FOR ALL TO authenticated USING (is_admin(auth.uid()));

CREATE POLICY "Users can manage own notifications" ON notifications
  FOR ALL TO authenticated USING (auth.uid() = user_id);

-- Create trigger function for auto-sync users to profiles
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  user_count int;
BEGIN
  SELECT COUNT(*) INTO user_count FROM profiles;
  INSERT INTO profiles (id, username, email, role)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'username', split_part(NEW.email, '@', 1)),
    NEW.email,
    CASE WHEN user_count = 0 THEN 'admin'::user_role ELSE 'user'::user_role END
  );
  RETURN NEW;
END;
$$;

-- Create trigger for new user confirmation
DROP TRIGGER IF EXISTS on_auth_user_confirmed ON auth.users;
CREATE TRIGGER on_auth_user_confirmed
  AFTER UPDATE ON auth.users
  FOR EACH ROW
  WHEN (OLD.confirmed_at IS NULL AND NEW.confirmed_at IS NOT NULL)
  EXECUTE FUNCTION handle_new_user();

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_call_logs_user_id ON call_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_call_logs_created_at ON call_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_meetings_user_id ON meetings(user_id);
CREATE INDEX IF NOT EXISTS idx_meetings_start_time ON meetings(start_time);
CREATE INDEX IF NOT EXISTS idx_tasks_user_id ON tasks(user_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);
CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date);
CREATE INDEX IF NOT EXISTS idx_documents_user_id ON documents(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
